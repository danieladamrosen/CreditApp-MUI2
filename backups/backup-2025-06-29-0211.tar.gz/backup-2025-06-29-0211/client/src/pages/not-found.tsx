import { Box, Card, CardContent, Typography, Container } from '@mui/material';
import { AlertCircle } from 'lucide-react';

export default function NotFoundPage() {
  return (
    <Container maxWidth="sm">
      <Box
        sx={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#f5f5f5',
        }}
      >
        <Card sx={{ width: '100%', maxWidth: 400, mx: 2 }}>
          <CardContent sx={{ pt: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
              <AlertCircle size={32} className="text-red-500" />
              <Typography variant="h4" component="h1" color="text.primary" fontWeight="bold">
                404 Page Not Found
              </Typography>
            </Box>

            <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
              Did you forget to add the page to the router?
            </Typography>
          </CardContent>
        </Card>
      </Box>
    </Container>
  );
}
