import { useState } from 'react';
import cloudyMascot from '../../assets/cloudy-logo.png';
import cloudyWink from '../../assets/cloudy-wink.png';

interface CloudyLoaderBlurProps {
  className?: string;
}

export function CloudyLoaderBlur({ className = '' }: CloudyLoaderBlurProps) {
  const [cloudyLoaded, setCloudyLoaded] = useState(false);
  const [winkLoaded, setWinkLoaded] = useState(false);

  const imageStyle: React.CSSProperties = {
    transform: 'scale(0.85)',
    filter:
      'drop-shadow(0 0 16px hsl(200, 60%, 65%)) drop-shadow(0 0 32px hsl(200, 45%, 75%)) drop-shadow(0 0 48px hsl(200, 30%, 85%))',
    opacity: 1,
    visibility: (cloudyLoaded && winkLoaded ? 'visible' : 'hidden') as 'visible' | 'hidden',
    transition: 'none',
  };

  return (
    <div className={`fixed inset-0 flex-center ${className}`}>
      <div className="relative w-36 md:w-32 h-36 md:h-32 flex-center">
        <img
          src={cloudyMascot}
          alt="Cloudy"
          className="w-24 md:w-20 h-24 md:h-20 object-contain cloudy-normal"
          style={imageStyle}
          onLoad={() => setCloudyLoaded(true)}
        />
        <img
          src={cloudyWink}
          alt="Cloudy Winking"
          className="w-24 md:w-20 h-24 md:h-20 object-contain absolute cloudy-winking"
          style={imageStyle}
          onLoad={() => setWinkLoaded(true)}
        />
      </div>
    </div>
  );
}
