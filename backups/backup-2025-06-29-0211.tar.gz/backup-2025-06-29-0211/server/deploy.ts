import express from "express";
import path from "path";
import { registerRoutes } from "./routes";
import { serveStatic, log } from "./vite";

const app = express();

// Health check endpoints for deployment platforms
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "healthy",
    service: "Credit Repair Dashboard",
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

app.head("/health", (req, res) => res.status(200).end());

app.get("/api/health", (req, res) => {
  res.status(200).json({ 
    status: "ok", 
    service: "active", 
    timestamp: Date.now(),
    environment: "production"
  });
});

// Middleware
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: false, limit: "10mb" }));

// Register API routes synchronously
registerRoutes(app);
log("API routes registered successfully");

// Serve static files first, then fallback to React app
try {
  const distPath = path.resolve(process.cwd(), "dist");
  app.use(express.static(distPath));
  
  // Serve React app for all non-API routes
  app.get("*", (req, res) => {
    if (req.path.startsWith("/api/") || req.path === "/health") {
      return res.status(404).json({ error: "Not found" });
    }
    res.sendFile(path.join(distPath, "index.html"));
  });
  
  log("Static file serving enabled");
} catch (error) {
  log(`Static files not available: ${error}`);
}

// Error handling
app.use((err: any, req: any, res: any, next: any) => {
  res.status(500).json({ 
    status: "error", 
    message: "Internal Server Error"
  });
});

const port = parseInt(process.env.PORT || "5000", 10);

const server = app.listen(port, "0.0.0.0", () => {
  log(`Production server running on port ${port}`);
  log(`Health checks: http://0.0.0.0:${port}/health`);
});

server.on("error", (err: any) => {
  log(`Server error: ${err.message}`);
  process.exit(1);
});

process.on("SIGTERM", () => {
  log("Shutting down gracefully");
  server.close(() => process.exit(0));
});

process.on("SIGINT", () => {
  log("Shutting down gracefully");
  server.close(() => process.exit(0));
});